__Painel-v20__

__Recomendado__
- Ubuntu 14

__Comando para instalar__

```wget https://raw.githubusercontent.com/fabricio94b/Painel-v20/main/install; chmod +x install; ./install```
#
#
#

![logo](https://github.com/fabricio94b/Painel-v20/blob/main/home.png)
