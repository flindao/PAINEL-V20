<?php
ini_set('max_execution_time', 150);
$DB_host = "localhost";
$DB_user = "root";
$DB_pass = "pass";
$DB_name = "painel";
date_default_timezone_set('America/Sao_Paulo');

$mysqli = new MySQLi($DB_host,$DB_user,$DB_pass,$DB_name);
if ($mysqli->connect_error) {
    die('Error: ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

$values = array();
$username = $_GET['username'];
$username = $mysqli->real_escape_string($username);
$password = $_GET['password'];
$password = $mysqli->real_escape_string($password);
$query = $mysqli->query("SELECT *
FROM
usuario_ssh
WHERE
login='".$username."'
AND senha='".$password."'
");

function dateDiffInDays($date1, $date2) 
{
    // Calculating the difference in timestamps
    $diff = strtotime($date2) - strtotime($date1);
      
    // 1 day = 24 hours
    // 24 * 60 * 60 = 86400 seconds
    return abs(round($diff / 86400));
}

if($query->num_rows > 0)
{
        $row = $query->fetch_assoc();
		
		$account_expiration = date("F j, Y", strtotime($row['data_validade']));
		$current_date = date('F j, Y');

        if($account_expiration != $current_date && $row['status'] == 1){
		$values['is_active'] = 'true';

		$values['expiration_date'] = date("d-m-Y", strtotime($row['data_validade']));
		$values['expiry'] = dateDiffInDays($current_date, $account_expiration) . " dias";
		if($row['online'] == 1) {
		$values['is_online'] = 'true';
		$values['online_date'] = date("F j, Y, g:i a", strtotime($row['online_start']));
		}else{
		$values['is_online'] = 'false';
		}
        }else{
        $values['is_active'] = 'false';
        }
}else{
        $values['is_active'] = 'false';
}

$data = $values;	
echo json_encode(($data));
?>
