<?php
require_once("pages/system/funcoes.php");
require_once("pages/system/seguranca.php");

$usuario = $_POST['login'];
$senha = $_POST['senha'];
$data_vencimento = $_POST['data_validade'];
$user_on = $_POST['online'];


if(empty($usuario)){
	echo '<script type="text/javascript">';
			                        echo 	'alert("Usuario em branco!");';
			                        echo	'window.location="area_cliente.php";';
			                        echo '</script>';
}
elseif(empty($senha)){
	echo '<script type="text/javascript">';
			                        echo 	'alert("Senha em branco!");';
			                        echo	'window.location="area_cliente.php";';
			                        echo '</script>';
}else{

	// Verifica se um formulário foi enviado
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$usuario = (isset($usuario)) ? $usuario : '';
        $senha = (isset($senha)) ? $senha : '';
		$data_vencimento = (isset($data_vencimento)) ? $data_vencimento : '';
		$user_on = (isset($user_on)) ? $user_on : '';
		 // Utiliza uma função criada no seguranca.php pra validar os dados digitados
        if (validaUsuario($usuario, $senha,"user") == true) {
			
			 $_SESSION['login'] = $resultado['login'];
			  $_SESSION['data_vencimento'] = $resultado['data_vencimento'];
			  
			echo '<script type="text/javascript">';
			                      //  echo 	'alert("Logado com sucesso!");';
			                        echo	'window.location="contassh.php";';
			                        echo '</script>';
		}else{

			                        echo '<script type="text/javascript">';
			                        echo 	'alert("Seu usuario nao existe ou esta expirado/bloqueado!");';
			                        echo	'window.location="area_cliente.php";';
			                        echo '</script>';
		}


	}
}

?>